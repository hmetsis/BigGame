import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;

public class Main {

    public static void main (String [] args) throws Exception {
        DefaultTerminalFactory terminalFactory = new DefaultTerminalFactory();
        Terminal terminal = terminalFactory.createTerminal();
        terminal.setCursorVisible(false);

        Block block = new Block();
        block.printBlock(terminal);
        Wall walls = new Wall();
        walls.printWall(terminal);
        char player = 'X';

        Thread.sleep(300);
        //keyStroke = terminal.pollInput();
        block.moveBlock(terminal);

        int x = 20;
        int y = 20;

        terminal.flush();

        boolean continueReadingInput = true;
        while (continueReadingInput) {
            Thread.sleep(300);
            //keyStroke = terminal.pollInput();
            block.moveBlock(terminal);

            KeyStroke keyStroke = null;

            do {
                Thread.sleep(5); // might throw InterruptedException
                keyStroke = terminal.pollInput();
            } while (keyStroke == null);

            KeyType type = keyStroke.getKeyType();

            int oldX = x;
            int oldY = y;

            switch (type) {
                case ArrowDown:
                    y++;
                    break;
                case ArrowRight:
                    x++;
                    break;
                case ArrowUp:
                    y--;
                    break;
                case ArrowLeft:
                    x--;
                    break;
            }


            boolean crashIntoWall = false;

            for (Position p : walls.getWall()) {
                if (p.getX() == x && p.getY() == y) {
                    crashIntoWall = true;
                }
            }

            if (crashIntoWall) {
                x = oldX;
                y = oldY;
            } else {
                terminal.setCursorPosition(oldX, oldY);
                terminal.putCharacter(' ');
                terminal.setCursorPosition(x, y);
                terminal.putCharacter(player);
            }
            //Ligga sist i loopen
//            terminal.setCursorPosition(x, y);
//            terminal.putCharacter(player);
//            terminal.setCursorPosition(oldX, oldY);
//            terminal.putCharacter(' ');
            terminal.flush();

        }
    }
}
