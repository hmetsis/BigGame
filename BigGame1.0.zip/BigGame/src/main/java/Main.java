import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;

public class Main {

    public static void main (String [] args) throws Exception {
        DefaultTerminalFactory terminalFactory = new DefaultTerminalFactory();
        Terminal terminal = terminalFactory.createTerminal();
        terminal.setCursorVisible(false);

        Block block = new Block();
        block.printBlock(terminal);

//        while(true) {
        Thread.sleep(300);
        //keyStroke = terminal.pollInput();
        block.moveBlock(terminal);

        int x = 20;
        int y = 20;

        terminal.flush();

        boolean continueReadingInput = true;
        while (continueReadingInput) {
            KeyStroke keyStroke = null;

            do {
                Thread.sleep(5); // might throw InterruptedException
                keyStroke = terminal.pollInput();
            } while (keyStroke == null);

            KeyType type = keyStroke.getKeyType();

            int oldX = x;
            int oldY = y;

            switch (type) {
                case ArrowDown:
                    y++;
                    break;
                case ArrowRight:
                    x++;
                    break;
                case ArrowUp:
                    y--;
                    break;
                case ArrowLeft:
                    x--;
                    break;
            }

            terminal.setCursorPosition(x, y);
            terminal.putCharacter('X');
            terminal.setCursorPosition(oldX, oldY);
            terminal.putCharacter(' ');
            terminal.flush();
        }

    }
}
